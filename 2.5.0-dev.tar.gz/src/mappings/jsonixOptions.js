module.exports = {
  namespacePrefixes: {
    "http://www.clarin.eu/cmd/cues/1": "cue",
    "http://www.w3.org/XML/1998/namespace": "xml"
  }
}
