module.exports = $.extend({},
  require("./actions/BrowserActions.js"),
  require("./actions/RestActions.js"),
  require("./actions/ComponentViewActions.js"),
  require("./actions/MessageActions.js"),
  require("./actions/EditorActions.js"),
  require("./actions/ValueSchemeActions.js")
);
